import React from "react";
import { ScrollView } from "react-native";


// UI – esclusivamente dalla tua libreria
import {
  Column,
  Row,
  Card,
  Heading,
  P,
  B,
  Quote,
  Small,
  TextGroup,
  Divider,
  Button,
  Link,
  CodeInline,
  Box,
  Code,
  useTheme
} from "ui";

export default function DocsIndex() {
  const { theme } = useTheme();

  return (
    <Column style={{ padding: 30, gap: 0 }}>
      <Card>
        <TextGroup>
          <Heading level={2}>Tokens</Heading>
          <Divider spacing={0}/>
          <Link href="/docs/tokens/colors" variant="button">Colors</Link>
        </TextGroup>
      </Card>
      <Card>
        <TextGroup>
          <Heading level={2}>Typography</Heading>
          <Divider spacing={0}/>
          <Link href="/docs/typography/Text" variant="button">Text</Link>
        </TextGroup>
      </Card>
    </Column>
  );
}
