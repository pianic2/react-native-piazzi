import React from "react";
import { ScrollView } from "react-native";


// UI – esclusivamente dalla tua libreria
import {
  Column,
  Row,
  Card,
  Heading,
  P,
  B,
  Quote,
  Small,
  TextGroup,
  Divider,
  Button,
  Link,
  CodeInline,
  Box,
  Code,
  useTheme
} from "ui";

export default function Colors() {
  const { theme } = useTheme();

  return (
    <Column style={{ padding: 30, gap: 0 }}>
      <Heading level={1}>Tokens</Heading>

    </Column>
  );
}
