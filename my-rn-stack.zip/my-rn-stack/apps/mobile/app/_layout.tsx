// apps/mobile/app/_layout.tsx

import { React } from "react";
import { Stack, Slot, usePathname } from "expo-router";

import { ThemeProvider, NavProvider, NavBar } from "ui";

// Config nav (statico, scalabile, testabile)
const NAV_ITEMS = [
  { label: "Home", href: "/" },
  { label: "Docs", href: "/docs" },
  { label: "Theme", href: "/theme" },
  { label: "Examples", href: "/examples" },
  { label: "Profile", href: "/profile" },
];

export default function RootLayout() {
  const pathname = usePathname();

  return (
    <ThemeProvider>
      <NavProvider items={NAV_ITEMS}>
        {/*
          NavBar:
          - decide layout (top / bottom / sidebar)
          - monta internamente BottomBar / SideBar / TopBar
        */}
        <NavBar
          bottomMaxItems={5}
          sidebarWidth={260}
        />

        {/* Contenuto delle route */}
        <Slot />
      </NavProvider>
    </ThemeProvider>
  );
}
