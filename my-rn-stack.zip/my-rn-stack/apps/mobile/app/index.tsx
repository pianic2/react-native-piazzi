import React from "react";
import { ScrollView } from "react-native";


// UI – esclusivamente dalla tua libreria
import {
  Column,
  Row,
  Card,
  Heading,
  P,
  B,
  Quote,
  Small,
  TextGroup,
  Divider,
  Button,
  Link,
  CodeInline,
  Box,
  Code,
  useTheme
} from "ui";

export default function Index() {
  const { theme } = useTheme();

  return (
      <Column style={{ flex: 1, padding: 30, gap: 0 }}>
        {/* ===============================
            HERO
        =============================== */}
        <TextGroup >
          <Heading level={1}>UI Library</Heading>

          <P>
            Una UI cross-platform pensata per React Native, Expo e Web.
            Inizia aggiungendo la libreria alla tua app ed inizia a programmare!
          </P>

          <Row>
            <Code>npm install ui</Code>
            <Link href="/docs" variant="button">
              Read Docs
            </Link>
          </Row>
          <Divider/>

        </TextGroup>


      <TextGroup>
        <Heading level={2}>Getting Started</Heading>

        <P>
          Inizia racchiudendo i tuoi <CodeInline>Slot</CodeInline>{" "}
          all'interno di <CodeInline>ThemeProvider</CodeInline>:{" "}
          da adesso potrai utilizzare il <CodeInline>ThemeContext</CodeInline>{" "}
          della libreria.
        </P>

        <Code>{`app/_layout.tsx

import { React } from "react";
import { Slot } from "expo-router";

import { ThemeProvider } from "ui";

export default function RootLayout() {

  return (
    <ThemeProvider>

      {/* Contenuto delle route */}
      <Slot />
    </ThemeProvider>
  );
}`}</Code>


        <Row>
          <Link href="/getting-started" variant="button">
            Getting Started
          </Link>
        </Row>

        <Divider/>
      </TextGroup>

      <TextGroup>
        <Heading level={2}>Filosofia della libreria</Heading>
        <Quote>Slogan: Ready to Paste</Quote>
        <P>Questa libreria non è una semplice raccolta di componenti.</P>
        <P>È un design system operativo, basato su questi principi:</P>

        <TextGroup spacing={0} style={{ marginLeft: theme.space.md }}>
          <B>• token centralizzati</B>
          <B>• API esplicite</B>
          <B>• zero comportamento “magico”</B>
          <B>• composizione sopra la configurazione</B>
          <B>• layout coerente per default</B>
        </TextGroup>
        <P>Se un componente richiede spiegazioni verbali per essere usato, è considerato incompleto.</P>
        <Divider/>
      </TextGroup>

      <TextGroup>
        <Heading level={2}>Componenti</Heading>
        <P>
        Per ogni componente troverai un <B>DOC</B> contente spiegazioni ed esempi.{" "}
        I componenti sono raggruppati gruppi:
        </P>
        <TextGroup>
          <Link href="docs/index" variant="button">Tipografia</Link>
          <Link href="docs/index" variant="button">Layout</Link>
          <Link href="docs/index" variant="button">Superfici</Link>
          <Link href="docs/index" variant="button">Sovrapposizione</Link>
          <Link href="docs/index" variant="button">Navigazione</Link>
          <Link href="docs/index" variant="button">Feedback</Link>
          <Link href="docs/index" variant="button">Form</Link>
        </TextGroup>
        <Divider/>
      </TextGroup>
      </Column>
  );
}
