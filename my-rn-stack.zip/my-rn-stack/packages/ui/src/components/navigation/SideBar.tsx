// ui/components/navigation/SideBar.tsx

export function SideBar() {
  return null; // su mobile usi BottomBar o BottomSheet
}
export default SideBar;
