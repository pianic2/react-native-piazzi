// ui/components/navigation/NavBar.tsx

import React, { useMemo } from "react";
import { Platform, View, ViewStyle } from "react-native";
import { useRouter } from "expo-router";
import { NavProvider, NavItem } from "./NavContext";
import { TopBar } from "./TopBar";
import { BottomBar } from "./BottomBar";
import { SideBar } from "./SideBar";

export interface NavBarProps {
  items: NavItem[];

  layout?: "auto" | "top" | "bottom" | "sidebar";

  // TopBar options
  title?: string;
  logo?: React.ReactNode;
  leftSlot?: React.ReactNode;
  centerSlot?: React.ReactNode;
  rightSlot?: React.ReactNode;

  // Sidebar options
  sidebarWidth?: number;

  style?: ViewStyle;
}

export function NavBar({
  items,
  layout = "auto",
  title,
  logo,
  leftSlot,
  centerSlot,
  rightSlot,
  sidebarWidth = 280,
  style,
}: NavBarProps) {
  const router = useRouter();

  const navigate = useMemo(() => (href: string) => router.push(href as any), [router]);

  const isWeb = Platform.OS === "web";
  const finalLayout = layout === "auto" ? (isWeb ? "top" : "bottom") : layout;

  return (
    <NavProvider items={items} navigate={navigate}>
      <View style={style}>
        {finalLayout === "top" && (
          <TopBar
            title={title}
            logo={logo}
            leftSlot={leftSlot}
            centerSlot={centerSlot}
            rightSlot={rightSlot}
          />
        )}

        {finalLayout === "bottom" && <BottomBar maxItems={5} />}

        {finalLayout === "sidebar" && <SideBar width={sidebarWidth} />}
      </View>
    </NavProvider>
  );
}
