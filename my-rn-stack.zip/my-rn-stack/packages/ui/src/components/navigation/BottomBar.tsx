// ui/components/navigation/BottomBar.tsx

import React from "react";
import { Platform, Pressable, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "../../theme/useTheme";
import { Text } from "../typography/Text";
import { useNavItems, useNavPathname, useNavigate } from "./NavContext";

export function BottomBar({ maxItems = 5 }: { maxItems?: 3 | 4 | 5 }) {
  if (Platform.OS === "web") return null;

  const { colors, theme } = useTheme();
  const insets = useSafeAreaInsets();

  const items = useNavItems().slice(0, maxItems);
  const pathname = useNavPathname();
  const navigate = useNavigate();

  return (
    <View
      style={{
        borderTopWidth: 1,
        borderTopColor: colors.border,
        backgroundColor: colors.surface,
        flexDirection: "row",
        justifyContent: "space-around",
        paddingTop: theme.space.xs,
        paddingBottom: insets.bottom + theme.space.xs,
      }}
    >
      {items.map((it) => {
        const active = pathname === it.href;
        const IconNode = active ? it.activeIcon ?? it.icon : it.icon;

        return (
          <Pressable
            key={it.href}
            onPress={() => navigate(it.href)}
            style={({ pressed }) => ({
              alignItems: "center",
              justifyContent: "center",
              minWidth: 64,
              opacity: pressed ? 0.7 : 1,
              paddingVertical: theme.space.xs,
            })}
          >
            {IconNode}
            <Text
              size="xs"
              weight={active ? "bold" : "medium"}
              style={{ color: active ? colors.primary : colors.textSecondary, marginTop: 4 }}
            >
              {it.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
